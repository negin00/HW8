#include <stdio.h>
#include <stdlib.h>
int main()
{
    typedef struct
    {
        int min;
        int sec;
    }time;

    typedef struct
    {
        char firstName[100];
        char lastName[100];
        char ID[100];
        time *record;
        time runningTime;

    }runner;

    int n;
    printf("Enter the runner's number: ");
    scanf("%d",&n);

    runner info[n];


    for(int i=0; i<n; i++)
        {
            info[i].record=(time *)malloc(sizeof(time));
            printf("\nEnter the runner %d first name: ",i+1);
            scanf("%s",info[i].firstName);
            printf("Enter the runner %d last name: ",i+1);
            scanf("%s",info[i].lastName);
            printf("Enter the runner %d information: ",i+1);
            scanf("%s",info[i].ID);
            printf("Enter the runner %d record: " ,i+1);
            scanf("%d",&info[i].record->min);
            scanf("%d",&info[i].record->sec);
            printf("Enter the runner %d running time: " ,i+1);
            scanf("%d",&info[i].runningTime.min);
            scanf("%d",&info[i].runningTime.sec);
        }


    int min_minute=info[0].runningTime.min;
    int min_sec=info[0].runningTime.sec;
    for(int j=1; j<n; j++)
    {
        if((info[j].runningTime.min<min_minute) ||((info[j].runningTime.min==min_minute) && (info[j].runningTime.sec<min_sec)))
        {
            min_minute=info[j].runningTime.min;
            min_sec=info[j].runningTime.sec;
        }
    }



    int min_record=info[0].record->min;
    int sec_record=info[0].record->sec;
    for(int j=0; j<n; j++)
    {
        if(((info[j].record->min)<min_record) || (((info[j].record->min) ==min_record) && ((info[j].record->sec)<sec_record)))
        {
            min_record=info[j].record->min;
            sec_record=info[j].record->sec;
        }
    }



    for(int i=0; i<n; i++)
    {
        if((info[i].runningTime.min==min_minute) && (info[i].runningTime.sec==min_sec))
        {
            printf("The winner is: %s %s\n", info[i].firstName,info[i].lastName);
            if(((info[i].record->min)<min_minute) ||  (((info[i].record->min)==min_minute) && ((info[i].record->sec)<min_sec)))
                printf("The winner has broken her record!\n");
            else
                printf("The winner didn't reach her record!\n");
            if(((info[i].record->min)<min_record) ||  (((info[i].record->min)<min_record) && ((info[i].record->sec)<sec_record)))
                printf("The winner can break the best record!\n");
            else
                printf("The winner can't break the best record!\n");
        }
    }


    runner temp;
    for(int i=0; i<n-1; i++)
        for(int j=i+1; j<n; j++)
        {
            if((info[i].runningTime.min)>(info[j].runningTime.min) || ((info[i].runningTime.min)==(info[j].runningTime.min) && (info[i].runningTime.sec)>(info[j].runningTime.sec)))
            {
                temp=info[i];
                info[i]=info[j];
                info[j]=temp;
            }
        }

    printf("First name\tLast name\tID\tRecord\tRunning time\n");
    for(int i=0; i<n; i++)
    {
        printf("%s\t\t%s\t\t%s\t%d:%d\t%d:%d\n",info[i].firstName,info[i].lastName,info[i].ID,info[i].record->min,info[i].record->sec,info[i].runningTime.min,info[i].runningTime.sec);
    }

    for (int i = 0; i < n; i++) {
        free(info[i].record);
    }

}